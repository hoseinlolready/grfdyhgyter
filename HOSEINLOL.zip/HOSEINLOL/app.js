const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const expressLayouts = require('express-ejs-layouts');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.use(expressLayouts);
app.set('layout', 'layout');

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

// Routes
app.get('/', (req, res) => {
    res.render('index', {
        name: 'Hosein',
        age: 16,
        skills: ['JavaScript', 'Java', 'Python'],
        projects: [
            {
                name: 'SecurityFixer',
                description: 'A security-focused project',
                link: 'https://SecurityFixer.hosein.lol/'
            },
            {
                name: 'GameLand',
                description: 'A gaming platform',
                link: 'https://www.gameland.sbs/'
            }
        ]
    });
});

app.get('/sponsor', (req, res) => {
    res.render('sponsor');
});

app.post('/sponsor', async (req, res) => {
    const { name, email, project, message } = req.body;
    
    const webhookUrl = 'https://discord.com/api/webhooks/1303031288915300393/LLwLTlbyoG8fRgkCsVMorKJSQ8_RIRDc31Vec_QDyRKJ3jxKyL6ow4q_AWHoL8dpGca5';
    
    try {
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                embeds: [{
                    title: 'New Sponsorship Request',
                    color: 0x00ff00,
                    fields: [
                        { name: 'Name', value: name },
                        { name: 'Email', value: email },
                        { name: 'Project', value: project },
                        { name: 'Message', value: message }
                    ],
                    timestamp: new Date()
                }]
            })
        });

        if (response.ok) {
            res.render('sponsor', { success: true });
        } else {
            res.render('sponsor', { error: true });
        }
    } catch (error) {
        console.error('Error sending webhook:', error);
        res.render('sponsor', { error: true });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
}); 