# Personal Portfolio Website

A modern personal portfolio website built with Node.js, Express, and EJS. Features include:
- About me section
- Projects showcase
- Sponsorship form with Discord webhook integration

## Features

- Responsive design using Tailwind CSS
- Modern UI with smooth animations
- Discord webhook integration for sponsorship requests
- Project showcase with direct links
- Skills display
- Contact form

## Prerequisites

- Node.js (v14 or higher)
- npm (Node Package Manager)

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd personal-website
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory (optional):
```
PORT=3000
```

## Running the Application

To start the development server:
```bash
npm run dev
```

For production:
```bash
npm start
```

The website will be available at `http://localhost:3000`

## Technologies Used

- Node.js
- Express.js
- EJS (Embedded JavaScript)
- Tailwind CSS
- Font Awesome
- Discord Webhook API 